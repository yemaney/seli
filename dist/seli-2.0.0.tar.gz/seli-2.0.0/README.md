<h1 align="center">
    seli
</h1>

<p align="center">
  <img  src="https://github.com/yemaney/seli/actions/workflows/test.yaml/badge.svg" alt="Test">
  <img  src="docs/docs/images/coverage.svg" alt="Coverage">
</p>

<h1 align="center">
    configurable selenium workers
</h1>

---

Documentation :memo: : https://yemaney.github.io/seli
