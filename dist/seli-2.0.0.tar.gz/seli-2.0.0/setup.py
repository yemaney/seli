# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['seli']

package_data = \
{'': ['*']}

install_requires = \
['selenium>=4.4.3,<5.0.0',
 'typer[all]>=0.6.1,<0.7.0',
 'webdriver-manager>=3.8.3,<4.0.0']

entry_points = \
{'console_scripts': ['seli = seli.main:app']}

setup_kwargs = {
    'name': 'seli',
    'version': '2.0.0',
    'description': 'extendable selenium worker',
    'long_description': '<h1 align="center">\n    seli\n</h1>\n\n<p align="center">\n  <img  src="https://github.com/yemaney/seli/actions/workflows/test.yaml/badge.svg" alt="Test">\n  <img  src="docs/docs/images/coverage.svg" alt="Coverage">\n</p>\n\n<h1 align="center">\n    configurable selenium workers\n</h1>\n\n---\n\nDocumentation :memo: : https://yemaney.github.io/seli\n',
    'author': 'yemaney',
    'author_email': 'yemane_@outlook.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9.5,<4.0.0',
}


setup(**setup_kwargs)
